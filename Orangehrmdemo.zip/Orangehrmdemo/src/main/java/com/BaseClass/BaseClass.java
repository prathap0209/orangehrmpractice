
package com.BaseClass;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;

public class BaseClass {

	public static WebDriver driver;
	public static WebDriverWait wait;

	// Launch Browser
	public static void launchBrowser() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	// Launch URL
	public static void launchUrl(String url) {

		driver.get(url);

	}

	// Send Keys
	public static void enterText(WebElement element, String value) {

		waitForVisibility(element);
		element.clear();
		element.sendKeys(value);

	}

	// Click
	public static void click(WebElement element) {

		waitForClickable(element);
		element.click();

	}

	// Get Title
	public static String getTitle() {

		return driver.getTitle();

	}

	// Get Current URL
	public static String getCurrentUrl() {

		return driver.getCurrentUrl();

	}

	// Verify Displayed
	public static boolean isDisplayed(WebElement element) {

		waitForVisibility(element);
		return element.isDisplayed();

	}

	// Wait for Visibility
	public static void waitForVisibility(WebElement element) {

		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.visibilityOf(element));

	}

	// Wait for Clickable
	public static void waitForClickable(WebElement element) {

		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(element));

	}

	// JavaScript Click
	public static void jsClick(WebElement element) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);

	}

	// Scroll Into View
	public static void scrollToElement(WebElement element) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);

	}

	// Screenshot
	public static void takeScreenshot(String fileName) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) driver;

		File src = ts.getScreenshotAs(OutputType.FILE);

		File des = new File("./Screenshots/" + fileName + ".png");

		FileHandler.copy(src, des);

	}

	// Page Refresh
	public static void refreshPage() {

		driver.navigate().refresh();

	}

	// Navigate Back
	public static void navigateBack() {

		driver.navigate().back();

	}

	// Navigate Forward
	public static void navigateForward() {

		driver.navigate().forward();

	}

	// Close Browser
	public static void closeBrowser() {

		driver.quit();

	}

}
