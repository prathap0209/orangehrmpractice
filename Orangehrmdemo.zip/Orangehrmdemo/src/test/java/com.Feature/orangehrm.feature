Feature: OrangeHRM Login and Dashboard Automation

Background:
Given User launches the Chrome browser
And User navigates to "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

Scenario: Verify Login Page Components
Then User should verify OrangeHRM login logo is displayed
And User should verify Username textbox is displayed
And User should verify Password textbox is displayed
And User should verify Login button is displayed
And User should verify Forgot Password link is displayed
And User should verify page title is "OrangeHRM"

Scenario: Verify Valid Login
When User enters username "Admin"
And User enters password "admin123"
And User clicks Login button
Then User should verify Dashboard page is displayed
And User should verify Dashboard URL contains "dashboard"
And User should verify Dashboard heading is displayed

Scenario: Verify Invalid Login
When User enters username "Admin123"
And User enters password "admin"
And User clicks Login button
Then User should verify Invalid Credentials message is displayed

#######
Scenario: Verify Forgot Password
When User clicks Forgot Password link
Then User should verify Reset Password page
When User enters reset username "Admin"
And User clicks Reset Password button
Then User should verify Reset Password success message


Scenario: Verify Dashboard Components
When User enters username "Admin"
And User enters password "admin123"
And User clicks Login button
Then User should verify Search textbox is displayed
And User should verify Left menu is displayed
And User should verify User profile icon is displayed
And User should verify Time at Work widget is displayed


Scenario: Verify Admin Module
When User enters username "Admin"
And User enters password "admin123"
And User clicks Login button
When User clicks Admin menu
Then User should verify System Users page
And User should verify Username field
And User should verify User Role dropdown
And User should verify Employee Name textbox
And User should verify Search button
And User should verify Reset button

########
Scenario: Verify Logout
When User enters username "Admin"
And User enters password "admin123"
And User clicks Login button
When User clicks User profile
And User clicks Logout
Then User should verify Login page is displayed