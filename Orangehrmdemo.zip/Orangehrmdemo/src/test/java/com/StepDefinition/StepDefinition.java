
package com.StepDefinition;

import org.junit.Assert;

import com.BaseClass.BaseClass;
import com.PomClass.PomClass;

import io.cucumber.java.en.*;

public class StepDefinition extends BaseClass {

	PomClass p;

	@Given("User launches the Chrome browser")
	public void user_launches_the_chrome_browser() {

		launchBrowser();
		p = new PomClass(driver);

	}

	@Given("User navigates to {string}")
	public void user_navigates_to(String url) {
		        launchUrl(url);

	}

	@Then("User should verify OrangeHRM login logo is displayed")
	public void user_should_verify_logo() {

		Assert.assertTrue(isDisplayed(p.logo));

	}

	@Then("User should verify Username textbox is displayed")
	public void verify_username() {

		Assert.assertTrue(isDisplayed(p.username));

	}

	@Then("User should verify Password textbox is displayed")
	public void verify_password() {

		Assert.assertTrue(isDisplayed(p.password));

	}

	@Then("User should verify Login button is displayed")
	public void verify_login_button() {
		Assert.assertTrue(isDisplayed(p.loginButton));

	}

	@Then("User should verify Forgot Password link is displayed")
	public void verify_forgot_password() {

		Assert.assertTrue(isDisplayed(p.forgotPassword));

	}

	@Then("User should verify page title is {string}")
	public void verify_title(String title) {

		Assert.assertEquals(title, getTitle());

	}

	@When("User enters username {string}")
	public void enter_username(String user) {
		enterText(p.username, user);

	}

	@When("User enters password {string}")
	public void enter_password(String pass) {

		enterText(p.password, pass);

	}

	@When("User clicks Login button")
	public void click_login() {

		click(p.loginButton);

	}

	@Then("User should verify Dashboard page is displayed")
	public void verify_dashboard() {

		Assert.assertTrue(isDisplayed(p.dashboardHeading));

	}

	@Then("User should verify Dashboard URL contains {string}")
	public void verify_url(String value) {
		Assert.assertTrue(getCurrentUrl().contains(value));

	}

	@Then("User should verify Dashboard heading is displayed")
	public void verify_dashboard_heading() {

		Assert.assertEquals("Dashboard", p.dashboardHeading.getText());

	}

	@Then("User should verify Invalid Credentials message is displayed")
	public void invalid_credentials() {

		Assert.assertTrue(isDisplayed(p.invalidCredentials));

	}

	@When("User clicks Forgot Password link")
	public void forgot_password() {
		click(p.forgotPassword);

	}

	@Then("User should verify Reset Password page")
	public void reset_password_page() {

		Assert.assertTrue(isDisplayed(p.resetPasswordHeading));

	}

	@When("User enters reset username {string}")
	public void reset_username(String user) {

	         	enterText(p.resetUsername, user);

	}

	@When("User clicks Reset Password button")
	public void reset_button() {
		   click(p.resetButton);

	}

	@Then("User should verify Reset Password success message")
	public void success_message() {

		Assert.assertTrue(isDisplayed(p.successMessage));

	}

	@Then("User should verify Search textbox is displayed")
	public void search_box() {

		Assert.assertTrue(isDisplayed(p.searchBox));

	}

	@Then("User should verify Left menu is displayed")
	public void left_menu() {

		Assert.assertTrue(isDisplayed(p.leftMenu));

	}

	@Then("User should verify User profile icon is displayed")
	public void profile_icon() {

		Assert.assertTrue(isDisplayed(p.profileIcon));

	}

	@Then("User should verify Time at Work widget is displayed")
	public void time_at_work() {
		Assert.assertTrue(isDisplayed(p.timeAtWork));

	}

	@When("User clicks Admin menu")
	public void admin_menu() {

		click(p.adminMenu);

	}

	@Then("User should verify System Users page")
	public void system_users_page() {

		Assert.assertTrue(isDisplayed(p.systemUsersHeading));

	}

	@Then("User should verify Username field")
	public void username_field() {

		Assert.assertTrue(isDisplayed(p.adminUsername));

	}

	@Then("User should verify User Role dropdown")
	public void user_role() {
		   Assert.assertTrue(isDisplayed(p.userRoleDropdown));

	}

	@Then("User should verify Employee Name textbox")
	public void employee_name() {

		Assert.assertTrue(isDisplayed(p.employeeName));

	}

	@Then("User should verify Search button")
	public void search_button() {
		Assert.assertTrue(isDisplayed(p.searchButton));

	}

	@Then("User should verify Reset button")
	public void reset_button_validation() {

		Assert.assertTrue(isDisplayed(p.resetBtn));

	}

	@When("User clicks User profile")
	public void user_profile() {

		click(p.profileIcon);

	}

	@When("User clicks Logout")
	public void logout() {

		click(p.logout);

	}

	@Then("User should verify Login page is displayed")
	public void login_page() {

		Assert.assertTrue(isDisplayed(p.loginButton));
		closeBrowser();

	}

}
