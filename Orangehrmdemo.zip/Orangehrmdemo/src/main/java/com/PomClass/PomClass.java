package com.PomClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PomClass {

	WebDriver driver;

	public PomClass(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Login Page

	@FindBy(xpath = "//img[@alt='company-branding']")
	public WebElement logo;

	@FindBy(name = "username")
	public WebElement username;

	@FindBy(name = "password")
	public WebElement password;

	@FindBy(xpath = "//button[@type='submit']")
	public WebElement loginButton;

	@FindBy(xpath = "//p[contains(text(),'Forgot')]")
	public WebElement forgotPassword;

	@FindBy(xpath = "//h6[text()='Dashboard']")
	public WebElement dashboardHeading;

	@FindBy(xpath = "//p[text()='Invalid credentials']")
	public WebElement invalidCredentials;

	// Forgot Password

	@FindBy(xpath = "//h6[text()='Reset Password']")
	public WebElement resetPasswordHeading;

	@FindBy(name = "username")
	public WebElement resetUsername;

	@FindBy(xpath = "//button[@type='submit']")
	public WebElement resetButton;

	@FindBy(xpath = "//h6[text()='Reset Password link sent successfully']")
	public WebElement successMessage;

	// Dashboard

	@FindBy(xpath = "//input[@placeholder='Search']")
	public WebElement searchBox;

	@FindBy(xpath = "//aside")
	public WebElement leftMenu;

	@FindBy(xpath = "//span[@class='oxd-userdropdown-tab']")
	public WebElement profileIcon;

	@FindBy(xpath = "//p[text()='Time at Work']")
	public WebElement timeAtWork;

	// Admin Module

	@FindBy(xpath = "//span[text()='Admin']")
	public WebElement adminMenu;

	@FindBy(xpath = "//h5[text()='System Users']")
	public WebElement systemUsersHeading;

	@FindBy(xpath = "(//input[@class='oxd-input oxd-input--active'])[2]")
	public WebElement adminUsername;

	@FindBy(xpath = "(//div[contains(@class,'oxd-select-text')])[1]")
	public WebElement userRoleDropdown;

	@FindBy(xpath = "//input[@placeholder='Type for hints...']")
	public WebElement employeeName;

	@FindBy(xpath = "//button[normalize-space()='Search']")
	public WebElement searchButton;

	@FindBy(xpath = "//button[normalize-space()='Reset']")
	public WebElement resetBtn;

	@FindBy(xpath = "//button[normalize-space()='Add']")
	public WebElement addButton;

	// Logout

	@FindBy(xpath = "//a[text()='Logout']")
	public WebElement logout;

}

