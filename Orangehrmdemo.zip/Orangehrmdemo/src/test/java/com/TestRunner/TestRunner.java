package com.TestRunner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.BaseClass.BaseClass;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\Users\\admin\\Downloads\\Practice\\Practice\\src\\test\\java\\com.Feature\\orangehrm.feature"},
		glue= {"com.StepDefinition"},
		plugin= {"pretty", "summary", "html:target/Cucumberreport/target.html"},
		dryRun = false
		)

public class TestRunner extends BaseClass {
	
	@BeforeClass
	public static void setup() {
		launchBrowser();
	}
	
	@AfterClass
	public static void close() {
		//closebrowser();
	}
	

}
